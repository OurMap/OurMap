// Written by :
// Manuel Cuesta 2007
// E-mail : camilocuesta@hotmail.com

// Variables globales ----------------------------------------------------------

// Request para el text suggester
var searchReq = createRequest();


// Funciones varias ------------------------------------------------------------

  function nuevaVentana( url ) {
	window.open( url,'popup', 'resizable=yes,menubar=no,location=no,toolbar=no,status=no,scrollbars=yes,directories=no,width=550,height=430,left=80,top=50');
  }


function validarCadena(str) {
  if ( str == null ) 
      return false;
  if ( str.length == 0 )
      return false;
  if ( str == 'null' )
      return false;
  return true;
}

function validarNumero(num) {

  if ( num == null )
     return false;
  if ( num == 'null' )
      return false;
  if ( num.length == 0 )
      return false;
  if ( isNaN(num) )
      return false;

  return true;
}


/** Obtiene el valor del objeto seleccionado en un select, o dropdown list */
function getSelectedValue( selectObject ) {
    return selectObject.options[ selectObject.selectedIndex ].value;
}    

// Obtiene el valor seleccionado de un radio
// returns the value of the radio button that is checked
// returns an empty string if none are checked, or
// there are no radio buttons
function getCheckedValue(radioObj) {
	if(!radioObj)
		return "";
	var radioLength = radioObj.length;
	if(radioLength == undefined)
		if(radioObj.checked)
			return radioObj.value;
		else
			return "";
	for(var i = 0; i < radioLength; i++) {
		if(radioObj[i].checked) {
			return radioObj[i].value;
		}
	}
	return "";
}

/** Carga el correspondiente url en en frame de menú */
function cargarMenu(url) {
    top.frames['barramenu'].location=url;
}


function checkAll(field, val)
{
   for (i = 0; i < field.length; i++)
	field[i].checked = val ;
}

function toggleBox(szDivID, iState) // 1 visible, 0 hidden
{
   var obj = document.layers ? document.layers[szDivID] :
   document.getElementById ?  document.getElementById(szDivID).style :
   document.all[szDivID].style;
   obj.visibility = document.layers ? (iState ? "show" : "hide") :
   (iState ? "visible" : "hidden");
}

function toggleLayer( whichLayer )
{
  var elem, vis;
  if( document.getElementById ) // this is the way the standards work
    elem = document.getElementById( whichLayer );
  else if( document.all ) // this is the way old msie versions work
      elem = document.all[whichLayer];
  else if( document.layers ) // this is the way nn4 works
    elem = document.layers[whichLayer];
  vis = elem.style;
  // if the style.display value is blank we try to figure it out here
  if(vis.display==''&&elem.offsetWidth!=undefined&&elem.offsetHeight!=undefined)
    vis.display = (elem.offsetWidth!=0&&elem.offsetHeight!=0)?'block':'none';
  vis.display = (vis.display==''||vis.display=='block')?'none':'block';
}

function isShown( whichLayer ) {
  var elem, vis;
  if( document.getElementById ) // this is the way the standards work
    elem = document.getElementById( whichLayer );
  else if( document.all ) // this is the way old msie versions work
      elem = document.all[whichLayer];
  else if( document.layers ) // this is the way nn4 works
    elem = document.layers[whichLayer];
  vis = elem.style;
  if ( vis.display==''||vis.display=='block')
      return true;
  else
      return false;
}

function showLayer( whichLayer )
{
  var elem, vis;
  if( document.getElementById ) // this is the way the standards work
    elem = document.getElementById( whichLayer );
  else if( document.all ) // this is the way old msie versions work
      elem = document.all[whichLayer];
  else if( document.layers ) // this is the way nn4 works
    elem = document.layers[whichLayer];
  vis = elem.style;
  // if the style.display value is blank we try to figure it out here
  if(vis.display==''&&elem.offsetWidth!=undefined&&elem.offsetHeight!=undefined)
    vis.display = 'block' ;
  vis.display = 'block' ;
}

function hideLayer( whichLayer )
{
  var elem, vis;
  if( document.getElementById ) // this is the way the standards work
    elem = document.getElementById( whichLayer );
  else if( document.all ) // this is the way old msie versions work
      elem = document.all[whichLayer];
  else if( document.layers ) // this is the way nn4 works
    elem = document.layers[whichLayer];
  vis = elem.style;
  // if the style.display value is blank we try to figure it out here
  if(vis.display==''&&elem.offsetWidth!=undefined&&elem.offsetHeight!=undefined)
    vis.display = 'none' ;
  vis.display = 'none';
}



// Funciones DOM ---------------------------------------------------------------

  // Elimina espacios delante y atrás de la cadena
  String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
  }  
    
  // Obtiene un hijo de un nodo por su nombre
  function getChild( node, childName ) {
      var size = node.childNodes.length;
      var i = 0;
      for ( i = 0; i < size; i ++ )
      {
          var child = node.childNodes[i];
          if ( child.nodeName == childName )
             return child;
      }
      
      return null;
  }
  
  
  
  // Obtiene los hijos de un nodo por su nombre
  function getChildren( node, childName ) {
      var size = node.childNodes.length;
      var i = 0;
      var cont = 0;
      var child;
      for ( i = 0; i < size; i ++ )
      {
          child = node.childNodes[i];
          if ( child.nodeName == childName )
             cont++;
      }
      
      var children = new Array(cont);
      var cont2 = 0;
      for ( i = 0; i < size; i ++ )
      {
          child = node.childNodes[i];
          if ( child.nodeName == childName )
             children[cont2++] = child;
      }
      
      return children;
  }
  
  
  // Obtiene un atributo de un nodo
  function getAttribute( node, attName ) {
      var size = node.attributes.length;
      var i = 0;
      for ( i = 0; i < size; i ++ )
      {
          var child = node.attributes[i];
          if ( child.nodeName == attName )
             return child;
      }
      
      return null;
  
  }

  // Obtiene el text o valor de un nodo, sin espacios adelante o atrás
  function getText( node ) {
     var text = getChild( node, '#text' );
     if ( text ) 
        return text.nodeValue.trim();
     else
        return null;
  }

  // Obtiene el primer nodo con id "nodeId" que encuentre entre los descendientes
  // de "node"
  function findElement(node, nodeId ) {

    try
    {
        if ( node.id == nodeId )
            return node;
    }
    catch ( err )
    {
    }

    for ( var i = 0; i < node.childNodes.length; i++ )
    {
        var temp = findElement( node.childNodes[i], nodeId );
        if ( temp )
            return temp
    }

    
    return null;
            
}    

function isIE() {
    if ( navigator.appName == 'Microsoft Internet Explorer' )
        return true;
    else
        return false;
}



// Funciones Ajax --------------------------------------------------------------

function  createRequest() {

      var http_request = false;

      if (window.XMLHttpRequest) 
      { // Mozilla, Safari,...
         http_request = new XMLHttpRequest();

         if (http_request.overrideMimeType) 
         {
            // set type accordingly to anticipated content type
            //http_request.overrideMimeType('text/xml');
            //http_request.overrideMimeType('text/html');
         }
      } 
      else if (window.ActiveXObject) 
      { // IE
         try 
         {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
         } 
         catch (e) 
         {
            try 
            {
               http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } 
            catch (e) {}
         }
      }

      if (!http_request) 
      {
         alert('Cannot create XMLHTTP instance');
         return false;
      }

      return http_request;


}

/** Ejecuta un requerimiento GET AJAX
* url :  es la dirección a la que quiere acceder
* onReadyFunction : Función a la que se debe llamar cuando llegue el requerimiento
*
*/
function makeRequest(url, onReadyFunction ) {

    var http_request = createRequest();

    if (!http_request) 
    {
        alert('Giving up :( Cannot create an XMLHTTP instance');
        return false;
    }

    http_request.onreadystatechange = onReadyFunction;
    http_request.open('GET', url, true);
    http_request.send(null);
    
    return true;

}

/** Ejecuta un requerimiento POST con AJAX */
function makePOSTRequest(http_request, url, parameters, onReadyFunction ) {
    
      http_request.onreadystatechange = onReadyFunction ;
      http_request.open('POST', url, true);
      http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      http_request.setRequestHeader("Content-length", parameters.length);
      http_request.setRequestHeader("Connection", "close");
      http_request.send(parameters);

}

/** Ejecuta el comando ajax, especificado por el nombre del comando "cmd", y
*   escribe el resultado en el div del documento con el id "divId"
*/
function executeAjax( url, parameters, divId ) {

    var http_request = createRequest();

    makePOSTRequest( http_request, url , parameters, function() {
        if (http_request.readyState == 4) 
        {
            if (http_request.status == 200) 
                document.getElementById( divId ).innerHTML = http_request.responseText;
            else
                alert('There was a problem with the request.');            
        }
    });


}

// Funciones Ajax para el text suggester ---------------------------------------

//Called from keyup on the search textbox.
//Starts the AJAX request.
function searchSuggest(url, parameters, ac ) {

    if (searchReq.readyState == 4 || searchReq.readyState == 0) 
    {
        
        makePOSTRequest( searchReq, url, parameters, function() {

            if (searchReq.readyState == 4 ) 
             {
                
		var xmlDoc = searchReq.responseXML;
                var root = xmlDoc.documentElement;

                
                var body = getChild(root, "body" );

                var nombres = getChildren( body, "nombre" );
                var size = nombres.length;
                var nomArray = new Array(size);
                for (i = 0; i < size ; i++ ) 
                       nomArray[i] = getText(nombres[i]);
                
                ac.actb_keywords = nomArray;

             }
            
        });

    } 
}

/*
 *
 * Template for ajax method
         var http_request = createRequest();

         var parameters =  'layerId=' + layerId;

         makePOSTRequest( http_request, 'deleteLayer.do' , parameters, function() {
         if (http_request.readyState == 4 && http_request.status == 200 )
         {
           var xmlDoc = http_request.responseXML;
           var root = xmlDoc.documentElement;
           var estado = getChild( root, 'estado' );
           if ( estado && getText(estado) == 'OK' )
           {
               t.deleteRow( rowNumber );
           }
           else if ( estado && getText(estado) == 'FAIL' )
           {
               var mensaje = getChild( root, 'mensaje' );
               alert( getText(mensaje) );
           }

         }
         });

 *  *
 */