/* $Id: README.txt,v 1.1.2.1 2009/10/13 13:26:44 aaron Exp $ */

/********************/
 Embedded Wave Field
/********************/

Author: Noah Biavaschi

Requires: Drupal 6, Content (CCK), Embedded Media Field
Optional: Views

This extensible module will create a field for node content types that can be used to display waves from providers
such as google.
